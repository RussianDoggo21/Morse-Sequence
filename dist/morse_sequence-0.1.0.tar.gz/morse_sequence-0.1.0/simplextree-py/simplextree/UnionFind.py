from _unionfind import UnionFind as UnionFindCpp

class UnionFind(UnionFindCpp):
  """ Union Find data structure """
  def __init__(n: int):
    pass 
